        <!--**********************************
            Sidebar start
        ***********************************-->
        <div class="quixnav">
            <div class="quixnav-scroll">
                <ul class="metismenu" id="menu">
                    <!-- <li class="nav-label first">Main Menu</li> -->
                    <li><a class="has-arrow1" href="../executivesummary/executivesummary.php" aria-expanded="false"><i class="fa fa-users" aria-hidden="true"></i><span class="nav-text">Executive Summary</span></a>
                      
                    </li>

                    <li><a class="has-arrow" href="javascript:void()" aria-expanded="false"><i class="fa fa-cog" aria-hidden="true"></i><span class="nav-text">Manufacturing</span></a>
                        <ul aria-expanded="false">
                            <li><a href="../manufacturingmodule/procurement_ratetbl.php">Procurement</a></li>
                            <li><a href="../manufacturingmodule/costproduction.php">Cost of Production</a></li>
                            <li><a href="../manufacturingmodule/manufactuirng_efficiency.php">Manufacturing Efficiency</a></li>
                        </ul>
                      
                    </li>
                    <li><a class="has-arrow" href="javascript:void()" aria-expanded="false"><i class="fa fa-signal" aria-hidden="true"></i><span class="nav-text">Sales</span></a>
                        <ul aria-expanded="false">
                            <li><a href="../salesmodule/portfolioperformance.php">Portfolio Performance</a></li>
                            <li><a href="../salesmodule/custsegment.php">Customer Segmentation</a></li>    
                            <li><a href="../salesmodule/associatebuy.php">Associate Buying</a></li>    
                            <li><a href="../salesmodule/pricegp.php">Correlation Analysis</a></li>      
                            <li><a href="../salesmodule/forecast.php">Forecasting</a></li>   

                        </ul>
                      
                    </li>
                    <li><a class="has-arrow" href="javascript:void()" aria-expanded="false"><i class="fa fa-line-chart" aria-hidden="true"></i><span class="nav-text">Profit</span></a>
                        <ul aria-expanded="false">


                            <li><a href="../profitmodule/grossprf_var.php">Gross profit varaiance analysis</a></li>  
                            <li><a href="../profitmodule/optimization.php">Optimization</a></li> 
                            <!-- <li><a href="../profitmodule/revenue_variance.php">Revenue variance analysis</a></li> -->
                            <li><a href="../profitmodule/revenue_variance.php">What If Simulation</a></li>
                            <!-- <li><a href="#">Simulation</a></li>    -->
                        </ul>
                      
                    </li>
                    <li><a class="has-arrow" href="javascript:void()" aria-expanded="false"><i class="fa fa-usd" aria-hidden="true"></i><span class="nav-text">Working Capital</span></a>
                        <ul aria-expanded="false">
                            <li><a href="../fginventory/summary.php">WC Summary</a></li>
                            <li><a href="../fginventory/rminventory.php">RM Inventory</a></li>
                            <li><a href="../fginventory/fg_inv.php">FG Inventory</a></li>  
                            <li><a href="../fginventory/accountrecevieable.php">Accout Receivable</a></li> 
                            <li><a href="../fginventory/accountpayble.php">Account Payable</a></li>   
                        </ul>
                      
                    </li>
                </ul>
            </div>
        </div>
        <!--**********************************
            Sidebar end
        ***********************************-->