<!DOCTYPE html>

<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Demystifier</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="./images/Demylogo.png">
    <link href="./vendor/pg-calendar/css/pignose.calendar.min.css" rel="stylesheet">
    <link href="./vendor/chartist/css/chartist.min.css" rel="stylesheet">
    <link href="./css/style.css" rel="stylesheet">
    <style>
        .fpbtn{
            color:#ff3325;
        }
        .fpbtn:hover{
            color:#0a7501;
        }
    </style>

</head>

<body style="background:#ffffff;">

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="sk-three-bounce">
            <div class="sk-child sk-bounce1"></div>
            <div class="sk-child sk-bounce2"></div>
            <div class="sk-child sk-bounce3"></div>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->


    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        <div class="nav-header"style="background: #0a7501;">
            <a href="" class="brand-logo">
                <img class="logo-abbr" src="./images/Demylogo.png" alt="">
                <img class="logo-compact" src="./images/Demytitle.png" alt="">
                <img class="brand-title" src="./images/Demytitle.png" alt="">
            </a>

          
        </div>
        <!--**********************************
            Nav header end
        ***********************************-->

        <!--**********************************
            Header start
        ***********************************-->
        <div class="header"style="background-color: #0a7501;">     </div>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->



<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body1">
            <div class="container-fluid p-0">
                         
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="container-fluid h-custom">
                                    <div class="row d-flex justify-content-center align-items-center h-100">
                                        <div class="col-md-9 col-lg-6 col-xl-5">
                                            <img src="./images/Demystifier.png"
                                            class="img-fluid" alt="Sample image">
                                        </div>
                                        <div class="col-md-8 col-lg-6 col-xl-4 offset-xl-1">
                                            <div>
                                                <h3>Login Form</h3>
                                            </div>
                                            <form  onsubmit="return checkLogin()">
                                                <div class="form-group">
                                                    <label>Email address</label>
                                                    <input type="text" class="form-control" placeholder="Enter email" id="username">
                                                </div>
                                                <div class="form-group">
                                                    <label for="exampleInputPassword1">Password</label>
                                                    <input type="password" class="form-control"placeholder="Password" id="password" required>
                                                </div>
                                                <div class="form-group float-right">
                                                <a href="forgotpwd.php"class="fpbtn">Forgot Password</a>
                                                </div>
                                                <div class="text-center text-lg-start mt-4 pt-2">
                                                    <button type="submit" class="btn btn-primary btn-lg">Login</button>
                                                </div>
                                            </form>
                                            <p id="error-message" style="color: red;"></p>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer pl-0" style="background: #0a7501;color: #ffffff;">
            <div class="copyright" style="text-align:center;">
                <p>Copyright © Demystier 2023</p>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
        <script>
        // Static credentials for demonstration purposes
        const validUsername = "demystifierpro.com";
        const validPassword = "1234";

        function checkLogin() {
            const username = document.getElementById("username").value;
            const password = document.getElementById("password").value;

            if (username === validUsername && password === validPassword) {
                // Successful login
                window.location.href = "./index_dashboard/index_dashboard.php";
                return false;
            } else {
                // Display error message
                document.getElementById("error-message").textContent = "Invalid username or password.";
                return false;
            }
        }
        </script>





    </div>

    <!-- Required vendors -->
    <script src="./vendor/global/global.min.js"></script>
    <script src="./js/quixnav-init.js"></script>
    <script src="./js/custom.min.js"></script>

    <script src="./vendor/chartist/js/chartist.min.js"></script>

    <script src="./vendor/moment/moment.min.js"></script>
    <script src="./vendor/pg-calendar/js/pignose.calendar.min.js"></script>


    <script src="./js/dashboard/dashboard-2.js"></script>
    <!-- Circle progress -->

</body>

</html>