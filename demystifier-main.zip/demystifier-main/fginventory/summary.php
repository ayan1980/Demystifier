<?php 
include '../commonpages/header.php'
?>
<?php 
include '../commonpages/sidebar.php'
?>

<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <div class="container-fluid">
                
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                        <div class="card-header">
                                <!-- <h4 class="card-title">Comparative Procurment Rate Hit Map</h4> -->
                                <div class="row page-titles mx-0 m-0 p-0">
                                    <div class="col-sm-12 p-md-0">
                                        <div class="welcome-text">
                                        <h4>Working Capital Summary</h4>
                                        </div>
                                    </div>      
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="row align-items-center">
                                    <div class="col-md-12 col-12">
                                        <img src="../images/slide5.png"
                                        class="img-fluid" alt="Sample image">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
<?php 
include '../commonpages/footer.php'
?>        