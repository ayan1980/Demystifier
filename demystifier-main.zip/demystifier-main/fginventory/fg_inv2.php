<?php 
include '../commonpages/header.php'
?>
<?php 
include '../commonpages/sidebar.php'
?>

<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <div class="container-fluid">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4>Price Elasticity- Maximum Price Point</h4>
                        </div>
                     </div>   
                </div> 
                <div class="row">
                    <div class="col-lg-12 col-12">
                       
                        <div class="card">
                            <div class="card-body">
                                <div class="row d-flex justify-content-center">
                                    <span class="fontsize20 text-dark">Correlation ASP & Unit Sold</span>
                                    <iframe src="fglevel3.html" frameborder="0" height="400" width="100%"></iframe>
                                </div> 
                            </div>
                        </div>
                    </div>
                            
                </div>
            </div>
        </div>
                
        <!--**********************************
            Content body end
        ***********************************-->
<?php 
include '../commonpages/footer.php'
?>        

                               